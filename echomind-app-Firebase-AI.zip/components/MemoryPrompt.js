export default function MemoryPrompt() {
  return (
    <section>
      <h2>Memory Prompt</h2>
      <p>Remember your business idea from last week?</p>
    </section>
  );
}
